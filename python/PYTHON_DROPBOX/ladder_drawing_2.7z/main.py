

from managegrid import ManageGrid, cellStruct
from elements import elementList, elementStruct
from ladder_drawing import Ui_testForm
import sys
from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Example(QtGui.QWidget):
    def __init__(self):
        QtGui.QWidget.__init__(self)
        self.testForm = Ui_testForm()
        self.testForm.setupUi(self)
        self.scene = QtGui.QGraphicsScene()
        self.testForm.graphicsView.setScene(self.scene)
        self.items = [QtGui.QGraphicsTextItem(),QtGui.QGraphicsRectItem()]#for squares and indexes that follow mouse
        self.testForm.graphicsView.viewport().setMouseTracking(True)
        self.testForm.graphicsView.viewport().installEventFilter(self)#for mouse functions
        self.Tools = elementList(elementStruct)
        self.setupDataGrid()#set up rung variables:

    def setupDataGrid(self):
        #x,y, element there, rung there, & there, element name, variable name, i/o connection.
        self.grid = [[]] # grid: list of rows  ex: grid [2][6] gives cell 6 in row(rung) 2
        self.reDoGrid = [[[]]]# list of grids for redo
        self.unDoGrid = [[[]]]# list of grids for undo
        self.currentTool = 0 #to track the tool being used
        width=10
        for i in range(width):#fill the first row
            self.grid[0].append(cellStruct(i*60, 60, "MT","Rung", None, None, None, None, False, False, False, False, False, False,None,None,None,None,None))
        for i in range(1,6):# add 5 more rungs to start
            ManageGrid(self.grid, self.scene,self.Tools,self.items).insertRung(i)

    def eventFilter(self, source, event):
        print "events : "
        if event.type() == QtCore.QEvent.MouseMove:
            self.eraseMarker()
            cellNum = self.findCell(event)
            self.showMarker(cellNum)
            print "MOUSE MOVING"
        else:
            pass
        return QtGui.QWidget.eventFilter(self, source, event)
        #self.ui.graphicsView.viewport().installEventFilter(self)

    def eraseMarker(self):
        itemlist = self.scene.items() #this is a list of ALL items in the scene
        for k in range(len(itemlist)): #compare to items placed last mousemove
            if itemlist[k] == self.items[0]:
                self.scene.removeItem(self.items[0])
            if itemlist[k] == self.items[1]:
                self.scene.removeItem(self.items[1])

    #puts a box around cell or marks or wire, or rung insert spot.  called by mouse move in event filter
    def showMarker(self, cellNum):
        i=cellNum[0]
        j=cellNum[1]
        #see if the item was deleted elsewhere, like by scene.clear()
        #self.eraseMarker()
        if cellNum != [None,None,None,None]:

            self.items[0] = QtGui.QGraphicsTextItem("%d, %d" %(i,j))
            self.items[0].setPos(self.grid[i][j].midPointX+35,self.grid[i][j].midPointY-35)
            self.scene.addItem(self.items[0])

            #show box around cell:
            x=self.grid[i][j].midPointX
            y=self.grid[i][j].midPointY-90
            w=58
            h=58
            self.items[1] = QtGui.QGraphicsRectItem(x,y,w,h)
            self.items[1].setPen(QtGui.QColor("blue"))
            self.scene.addItem(self.items[1])

    def findCell(self,event):
        #Pos = event.globalPos() #doesn't stay when window moves
        #Pos = event.pos()# offset -60,-50
        #Pos = self.ui.graphicsView.mapToScene(event.globalPos()) #doesn't stay when window moves
        Pos = self.testForm.graphicsView.mapToScene(event.pos())
        #things that don't work:

        #Pos = event.screenPos()
        #Pos = self.ui.graphicsView.mapToScene(event.screenPos())
        #Qmousevent has no attribute screenPos

        #Pos = event.scenePos()
        #Pos = self.ui.graphicsView.mapToScene(event.scenePos())
        #Qmousevent has no attribute scenePos

        #x=Pos.x()-172
        x=Pos.x()  -30
        y=Pos.y() +60

        #self.testForm.label_2.setNum(x)# set x,y display values
        #self.testForm.label_4.setNum(y)
        if 1 == 1:#disabled if
            #pos = self.ui.graphicsView.mapToScene(event.pos())
            #pos = event.pos()
            #x = pos.x()-30
            #y = pos.y()+60
            cellNum = [None,None,None,None]
            for i in range(len(self.grid)): #cellNum[0]=i    #backwards: row,col
                for j in range(len(self.grid[i])):
                    if (self.grid[i][j].midPointX-30< x < self.grid[i][j].midPointX+30) and (self.grid[i][j].midPointY-30< y< self.grid[i][j].midPointY+30):
                        cellNum = [i,j,None,None]
                        if y<self.grid[cellNum[0]][cellNum[1]].midPointY: #insert above
                            cellNum[2] = "up"
                        else:#insert below
                            cellNum[2] = "dn"
                        if x<self.grid[cellNum[0]][cellNum[1]].midPointX: #insert left or right
                            cellNum[3] = "rt"
                        else:
                            cellNum[3] = "lt"
        return cellNum

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec_())




