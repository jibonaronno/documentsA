

from managegrid import ManageGrid, cellStruct
from elements import elementList, elementStruct
from ladder_drawing import Ui_testForm
import sys
from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Example(QtGui.QWidget):
    def __init__(self):
        QtGui.QWidget.__init__(self)
        self.testForm = Ui_testForm()
        self.testForm.setupUi(self)
        self.scene = QtGui.QGraphicsScene()
        self.testForm.graphicsView.setScene(self.scene)
        self.items = [QtGui.QGraphicsTextItem(),QtGui.QGraphicsRectItem()]#for squares and indexes that follow mouse
        self.testForm.graphicsView.viewport().installEventFilter(self)#for mouse functions
        self.Tools = elementList(elementStruct)
        self.setupDataGrid()#set up rung variables:

    def setupDataGrid(self):
        #x,y, element there, rung there, & there, element name, variable name, i/o connection.
        self.grid = [[]] # grid: list of rows  ex: grid [2][6] gives cell 6 in row(rung) 2
        self.reDoGrid = [[[]]]# list of grids for redo
        self.unDoGrid = [[[]]]# list of grids for undo
        self.currentTool = 0 #to track the tool being used
        width=10
        for i in range(width):#fill the first row
            self.grid[0].append(cellStruct(i*60, 60, "MT","Rung", None, None, None, None, False, False, False, False, False, False,None,None,None,None,None))
        for i in range(1,6):# add 5 more rungs to start
            ManageGrid(self.grid, self.scene,self.Tools,self.items).insertRung(i)

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec_())




