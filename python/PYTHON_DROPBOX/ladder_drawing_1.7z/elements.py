

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class elementStruct():
    def __init__(self, toolName, pixmap , position, toolType):
        self. toolName = toolName
        self. pixmap = pixmap
        self. position = position
        self. toolType = toolType
        #example:
        #toolName= "contNO"
        #pixmap= QtGui.QPixmap(_fromUtf8(":/icons/icons/contact_NO_big.png"))
        #position= "Any" or "Right"
        #toolType = "Rung" or "Element" or "blankOR"

class elementList():#list of tools.  uses elementStruct
    def __init__(self, elementStruct):
        self.toolList = [elementStruct(0,0,0,0)]
        ##001##
        #list elements here:
        self.toolList.append(elementStruct("contNO",QtGui.QPixmap(_fromUtf8(":/icons/icons/contact_NO.svg")),"any","Element"))
        self.toolList.append(elementStruct("contNC",QtGui.QPixmap(_fromUtf8(":/icons/icons/contact_NC.svg")),"any","Element"))
        self.toolList.append(elementStruct("Coil",QtGui.QPixmap(_fromUtf8(":/icons/icons/Coil.svg")),"right","Element"))
        self.toolList.append(elementStruct("CoilNot",QtGui.QPixmap(_fromUtf8(":/icons/icons/Coil_not.svg")),"right","Element"))
        self.toolList.append(elementStruct("Rising",QtGui.QPixmap(_fromUtf8(":/icons/icons/rising.svg")),"any","Element"))
        self.toolList.append(elementStruct("Fall",QtGui.QPixmap(_fromUtf8(":/icons/icons/falling.svg")),"any","Element"))
        self.toolList.append(elementStruct("Timer",QtGui.QPixmap(_fromUtf8(":/icons/icons/timer.svg")),"any","Element"))
        self.toolList.append(elementStruct("Counter",QtGui.QPixmap(_fromUtf8(":/icons/icons/counter.svg")),"any","Element"))

        self.toolList.append(elementStruct("Equals",QtGui.QPixmap(_fromUtf8(":/icons/icons/equ.svg")),"any","Element"))
        self.toolList.append(elementStruct("Plus",QtGui.QPixmap(_fromUtf8(":/icons/icons/plus.svg")),"right","Element"))
        self.toolList.append(elementStruct("Minus",QtGui.QPixmap(_fromUtf8(":/icons/icons/minus.svg")),"right","Element"))
        self.toolList.append(elementStruct("Move",QtGui.QPixmap(_fromUtf8(":/icons/icons/move.svg")),"right","Element"))
        self.toolList.append(elementStruct("Mult",QtGui.QPixmap(_fromUtf8(":/icons/icons/times.svg")),"right","Element"))
        self.toolList.append(elementStruct("Greater",QtGui.QPixmap(_fromUtf8(":/icons/icons/greater_than.svg")),"any","Element"))
        self.toolList.append(elementStruct("Lessthan",QtGui.QPixmap(_fromUtf8(":/icons/icons/less_than.svg")),"any","Element"))
        self.toolList.append(elementStruct("GreaterOrEq",QtGui.QPixmap(_fromUtf8(":/icons/icons/greater_than_or_eq.svg")),"any","Element"))
        self.toolList.append(elementStruct("LessOrEq",QtGui.QPixmap(_fromUtf8(":/icons/icons/less_than_or_eq.svg")),"any","Element"))
        self.toolList.append(elementStruct("PWM",QtGui.QPixmap(_fromUtf8(":/icons/icons/PWM.svg")),"right","Element"))
        self.toolList.append(elementStruct("ADC",QtGui.QPixmap(_fromUtf8(":/icons/icons/ADC.svg")),"right","Element"))
        self.toolList.append(elementStruct("Divide",QtGui.QPixmap(_fromUtf8(":/icons/icons/divide.svg")),"right","Element"))
        #Equals Plus Minus Move Mult Greater Lessthan GreaterOrEq LessOrEq PWM ADC Divide

        self.toolList.append(elementStruct("addRung",None,None,"Rung"))
        self.toolList.append(elementStruct("Widen",None,None,"Rung"))
        self.toolList.append(elementStruct("blankOR",None,None,"OR"))
        self.toolList.append(elementStruct("Del",None,None,"Rung"))
        self.toolList.append(elementStruct("ORwire",None,None,"Rung"))
        self.toolList.append(elementStruct("Narrow",None,None,"Rung"))

