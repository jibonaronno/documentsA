# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ladder_drawing.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_testForm(object):
    def setupUi(self, testForm):
        testForm.setObjectName(_fromUtf8("testForm"))
        testForm.resize(859, 602)
        self.graphicsView = QtGui.QGraphicsView(testForm)
        self.graphicsView.setGeometry(QtCore.QRect(60, 60, 781, 521))
        self.graphicsView.setObjectName(_fromUtf8("graphicsView"))

        self.retranslateUi(testForm)
        QtCore.QMetaObject.connectSlotsByName(testForm)

    def retranslateUi(self, testForm):
        testForm.setWindowTitle(_translate("testForm", "Test Form", None))

