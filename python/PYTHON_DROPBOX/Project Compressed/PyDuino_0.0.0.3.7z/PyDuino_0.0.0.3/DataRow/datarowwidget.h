#ifndef DATAROWWIDGET_H
#define DATAROWWIDGET_H

#include <QWidget>

namespace Ui {
class DatarowWidget;
}

class DatarowWidget : public QWidget
{
    Q_OBJECT

public:
    explicit DatarowWidget(QWidget *parent = 0);
    ~DatarowWidget();

private:
    Ui::DatarowWidget *ui;
};

#endif // DATAROWWIDGET_H
