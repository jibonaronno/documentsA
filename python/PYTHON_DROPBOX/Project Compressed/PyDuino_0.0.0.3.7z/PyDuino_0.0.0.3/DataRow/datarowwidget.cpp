#include "datarowwidget.h"
#include "ui_datarowwidget.h"

DatarowWidget::DatarowWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DatarowWidget)
{
    ui->setupUi(this);
}

DatarowWidget::~DatarowWidget()
{
    delete ui;
}
