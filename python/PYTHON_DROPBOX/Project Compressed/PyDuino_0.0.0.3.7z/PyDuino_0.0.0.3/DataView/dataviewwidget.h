#ifndef DATAVIEWWIDGET_H
#define DATAVIEWWIDGET_H

#include <QWidget>

namespace Ui {
class DataviewWidget;
}

class DataviewWidget : public QWidget
{
    Q_OBJECT

public:
    explicit DataviewWidget(QWidget *parent = 0);
    ~DataviewWidget();

private:
    Ui::DataviewWidget *ui;
};

#endif // DATAVIEWWIDGET_H
