#include "dataviewwidget.h"
#include "ui_dataviewwidget.h"

DataviewWidget::DataviewWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DataviewWidget)
{
    ui->setupUi(this);
}

DataviewWidget::~DataviewWidget()
{
    delete ui;
}
