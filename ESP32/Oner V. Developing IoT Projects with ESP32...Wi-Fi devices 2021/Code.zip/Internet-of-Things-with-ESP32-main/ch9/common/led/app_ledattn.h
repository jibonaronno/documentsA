
#ifndef appled_attn_h_
#define appled_attn_h_

#include <stdbool.h>

#define ATTN_LED_PIN 19

void appled_init(void);
void appled_set(bool);

#endif