ESP-IDF HD44780 (I2C) Driver
============================

This is a basic port of the liquid crystal arduino library for driving an LCD using the HD44780 driver and PC8574 I2C I/O expander. 

Please see main.c file for example usage. 
