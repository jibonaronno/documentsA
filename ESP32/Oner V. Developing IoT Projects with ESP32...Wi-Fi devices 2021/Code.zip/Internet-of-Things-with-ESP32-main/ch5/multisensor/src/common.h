
#ifndef common_h_
#define common_h_

typedef struct {
    int temperature;
    int humidity;
    int pressure;
    int light;
} sensor_reading_t;


#endif