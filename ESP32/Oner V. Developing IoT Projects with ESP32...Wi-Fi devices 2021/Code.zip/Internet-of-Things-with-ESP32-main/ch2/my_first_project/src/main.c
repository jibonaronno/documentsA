#include <stdio.h>

void app_main()
{
    printf("hello world\n");
    fflush(stdout);
}
