#include "brushfactory.h"

BrushFactory::BrushFactory(QObject *parent)
    : QObject{parent}
{}
