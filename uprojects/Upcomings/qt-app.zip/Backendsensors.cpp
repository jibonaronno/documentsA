#include "Backendsensors.h"

BackendSensors::BackendSensors(QObject *parent)
    : QObject{parent}
{}

int BackendSensors::heartRate() const
{
    return m_heartRate;
}

int BackendSensors::nibp() const
{
    return m_nibp;
}

int BackendSensors::spo2() const
{
    return m_spo2;
}

int BackendSensors::rr() const
{
    return m_rr;
}

float BackendSensors::temp() const
{
    return m_temp;
}

int BackendSensors::batteryLevel() const
{
    return m_batteryLevel;
}

int BackendSensors::signalLevel() const
{
    return m_signalLevel;
}


void BackendSensors::updateHeartRate(int newRate)
{
    if (m_heartRate != newRate) {
        m_heartRate = newRate;
        emit heartRateChanged();
    }
}

void BackendSensors::updateNibp(int newNibp)
{
    if (m_nibp != newNibp) {
        m_nibp = newNibp;
        emit nibpChanged();
    }
}

void BackendSensors::updateSpo2(int newSpo2)
{
    if (m_spo2 != newSpo2) {
        m_spo2 = newSpo2;
        emit spo2Changed();
    }
}

void BackendSensors::updateRr(int newRr)
{
    if (m_rr != newRr) {
        m_rr = newRr;
        emit rrChanged();
    }
}

void BackendSensors::updateTemp(float newTemp)
{
    if (m_temp != newTemp) {
        m_temp = newTemp;
        emit tempChanged();
    }
}

void BackendSensors::updateBatteryLevel(int newBatteryLevel)
{
    if (m_batteryLevel != newBatteryLevel) {
        m_batteryLevel = newBatteryLevel;
        emit batteryLevelChanged();
    }
}

void BackendSensors::updateSignalLevel(int newSignalLevel)
{
    if (m_signalLevel != newSignalLevel) {
        m_signalLevel = newSignalLevel;
        emit signalLevelChanged();
    }
}







