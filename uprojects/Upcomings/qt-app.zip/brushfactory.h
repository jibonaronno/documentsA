#ifndef BRUSHFACTORY_H
#define BRUSHFACTORY_H

#include <QObject>
#include <QBrush>
#include <QLinearGradient>
#include <QtQml/qqml.h>

class BrushFactory : public QObject
{
    Q_OBJECT
    QML_SINGLETON
    QML_ELEMENT
public:
    explicit BrushFactory(QObject *parent = nullptr);
public:
    Q_INVOKABLE QBrush gradientFromColor(const QColor& color)
    {
        // customize the gradient color
        QLinearGradient gradient(QPointF(0, 0), QPointF(0, 1));
        gradient.setCoordinateMode(QGradient::ObjectBoundingMode);
        gradient.setColorAt(0.0, color);
        gradient.setColorAt(0.5, QColor(0, 0, 0, 255));

        gradient.setColorAt(1.0, QColor(0, 0, 0, 255));

        return QBrush(gradient);
    }
signals:
};

#endif // BRUSHFACTORY_H
