#include <QApplication>
#include <QQmlApplicationEngine>
#include "BackendSensors.h"
#include "brushfactory.h"
#include <QTimer>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QQmlApplicationEngine engine;

    BackendSensors *backendSensors = new BackendSensors(&app);
    qmlRegisterSingletonInstance("com.company.BackendSensors", 1, 0, "BackendSensors", backendSensors);

    BrushFactory *brushFactory = new BrushFactory(&app);
    qmlRegisterSingletonInstance("com.company.brushFactory", 1, 0, "BrushFactory", brushFactory);


    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.loadFromModule("medical-device-qt", "Main");

    // Simulate heart rate sensor updates using a QTimer
    QTimer timer;
    QObject::connect(&timer, &QTimer::timeout, [&backendSensors]() {
        static int i = 60;  // Start with a baseline heart rate
        i ++;  // Randomly adjust the heart rate
        backendSensors->updateHeartRate(30);  // Simulate receiving a heart rate value
        backendSensors->updateNibp(i);
        backendSensors->updateRr(i);
        backendSensors->updateTemp(100.6);
        backendSensors->updateSpo2(i);
        backendSensors->updateSignalLevel(55);
        backendSensors->updateBatteryLevel(30);
    });

    timer.start(1000);  // Update heart rate every second

    return app.exec();
}
