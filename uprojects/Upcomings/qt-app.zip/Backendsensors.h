#ifndef BACKENDSENSORS_H
#define BACKENDSENSORS_H

#include <QObject>

class BackendSensors : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int heartRate  READ heartRate  NOTIFY heartRateChanged)
    Q_PROPERTY(int nibp  READ nibp  NOTIFY nibpChanged)
    Q_PROPERTY(int spo2  READ spo2  NOTIFY spo2Changed)
    Q_PROPERTY(int rr  READ rr  NOTIFY rrChanged)
    Q_PROPERTY(float temp  READ temp  NOTIFY tempChanged)
    Q_PROPERTY(int batteryLevel  READ batteryLevel  NOTIFY batteryLevelChanged)
    Q_PROPERTY(int signalLevel  READ signalLevel  NOTIFY signalLevelChanged)

public:
    explicit BackendSensors(QObject *parent = nullptr);
    int heartRate() const;
    int nibp() const;
    int spo2() const;
    int rr() const;
    float temp() const;
    int batteryLevel() const;
    int signalLevel() const;

public slots:
    void updateHeartRate(int newRate);
    void updateNibp(int newNibp);
    void updateSpo2(int newSpo2);
    void updateRr(int newRr);
    void updateTemp(float newTemp);
    void updateBatteryLevel(int newBatteryLevel);
    void updateSignalLevel(int newSignalLevel);


signals:
    void heartRateChanged();
    void nibpChanged();
    void spo2Changed();
    void rrChanged();
    void tempChanged();
    void batteryLevelChanged();
    void signalLevelChanged();

private:
    int m_heartRate = 0;
    int m_nibp = 0;
    int m_spo2 = 0;
    int m_rr = 0;
    float m_temp = 0;
    int m_batteryLevel = 0;
    int m_signalLevel = 0;
};

#endif // BACKENDSENSORS_H
