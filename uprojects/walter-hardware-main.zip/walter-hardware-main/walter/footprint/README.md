# Walter footprint

Walter uses 2.54mm pin headers with 14 pins on each side. The mounted part is 
Würth Elektronik 61001418221 with a 6mm pin height or a compatible part with 
slightly less high pins.

Walter can be soldered directly onto your design using wave soldering or by
making use of matching sockets. The recommended socket is the Würth Elektronik
61301411821