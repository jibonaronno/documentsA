/*
 * httpd_cgi_ssi.h
 *
 *  Created on: 6 Dec 2021
 *      Author: v.simonenko
 */

#ifndef LWIP_PORT_HTTPD_CGI_SSI_H_
#define LWIP_PORT_HTTPD_CGI_SSI_H_

void LwIP_HTTPD_Init();

#endif /* LWIP_PORT_HTTPD_CGI_SSI_H_ */
